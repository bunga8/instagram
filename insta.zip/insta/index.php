<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindulu");
}
include "koneksi.php";
$sql="SELECT*FROM post ORDER BY no DESC";
$query=mysqli_query($koneksi,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="shortcut icon" href="data/miaww.jpg">


    <title>Kocheng</title>
    <style>
        .zoom{
        overflow: hidden;
        margin: 0 auto;
      }
      .zoom img {
        width: 100%;
        transition: 0.2s all ease-in-out;
      }
      .zoom:hover img {
        transform: scale(1.2);
        cursor: pointer;
      }
    </style>
</head>

<body class="" style="background-color: lightblue;">
<body>
    <div class="container">
        <center>
<!-- Image and text -->
  <nav class="navbar bg-body-tertiary">
  <div class="container-fluid">
      
      
    <a class="navbar-brand" href="#">
      <img src="/insta/data/miaww.jpg" width="50" height="50">
      KOCHENG
    </a>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
    <a class="navbar-brand" href="index.php">KOCHENG HOME</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
    <a class="nav-link" data-bs-toggle="modal" data-bs-target="#exampleModal"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-lg" viewBox="0 0 16 16">
    <path fill-rule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2Z"/>
    </svg></button></a></a>
       
    <a class="nav-link" href="logout.php"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-sign-turn-slight-right-fill" viewBox="0 0 16 16">
    <path d="M6.95.435c.58-.58 1.52-.58 2.1 0l6.515 6.516c.58.58.58 1.519 0 2.098L9.05 15.565c-.58.58-1.519.58-2.098 0L.435 9.05a1.482 1.482 0 0 1 0-2.098L6.95.435Zm1.385 6.547.8 1.386a.25.25 0 0 0 .451-.039l1.06-2.882a.25.25 0 0 0-.192-.333l-3.026-.523a.25.25 0 0 0-.26.371l.667 1.154-.621.373A2.5 2.5 0 0 0 6 8.632V11h1V8.632a1.5 1.5 0 0 1 .728-1.286l.607-.364Z"/>
    </svg></a>
        
      </div>
    </div>
  </div>
</nav>

    

    <div>
        
        <ul class="list-inline">
            <li class="list-inline-item">
            
            </a>
            </li>
            <li class="list-inline-item">
                
              
            </li>
        
        </ul>
    </div>
    

  </div>
</nav>

<?php while($post=mysqli_fetch_assoc($query)){?>
<div class="container d-flex justify-content-center">
    
    <div class="card" style="width: 30rem;">
    <div class="card-body">
    <div class="zoom">
    <img src="data/<?= $post['foto']?>" alt="" width="300">
    
    <div class="card-body">
  
        <h5 class="card-title"><?= $post['caption']?></h5>
        <p class="card-text"><?= $post['lokasi']?></p>

        
        <a data-bs-toggle="modal" data-bs-target="#editModal<?=$post['no']?>"><button class = "btn btn-danger">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pen" viewBox="0 0 16 16">
    <path d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001zm-.644.766a.5.5 0 0 0-.707 0L1.95 11.756l-.764 3.057 3.057-.764L14.44 3.854a.5.5 0 0 0 0-.708l-1.585-1.585z"/>
    </svg>

        <a  href="hapus.php?no=<?= $post['no']?>"><button class="btn btn-success">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16">
        <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z"/>
        </svg></button></a>
    </div>
    
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel"></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        
        <label for="" class="form-label">foto</label><br>
        <input class="form-control" type="file" name="foto" id="" required><br><br>

        <label for="" class="form-label">Caption</label><br>
        <input class="form-control" type="text" name="caption" id="" autocomplete="off"><br>

        <label for="" class="form-label">Lokasi</label><br>
        <input class="form-control" type="text" name="lokasi" id="" autocomplete="off"><br><br>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <input type="submit" name="simpan" class="btn btn-primary">
        </div>
    </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="editModal<?=$post['no']?>" tabindex="-1" aria-labelledby="editModal<?=$post['no']?>" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="editModalLabel"></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        
      <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">

        <label for="">foto</label><br>
        <input type="file" name="foto" id="" value="<?= $post['foto'] ?>" ><br><br>
        <img src="data/<?= $post['foto'] ?>" width="340" height="250" alt="" ><br><br>
        
        <label for="">Caption</label>
        <input  class="form-control" type="text" name="caption" id="" value="<?= $post['caption'] ?>" autocomplete="off"><br>

        <label for="">Lokasi</label>
        <input class="form-control" type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" name="edit" class="btn btn-primary">Save changes</button>
        </div>
    </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>

</body>
</html>