<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
    
<body>
    <h1>Tambah Postingan</h1>
    <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
    <label for="">Foto</label><br>
    <input type="file" name="foto" id="" required><br>
    <label for="">Caption</label><br>
    <input type="text" name="caption" id="" autocomplate="off"><br>
    <label for="">Lokasi</label><br>
    <input type="text" name="lokasi" id="" autocomplate="off"><br><br>
    <input type="submit" value="tambah" name="Posting">
    </form>
</body>
</html>